#include <iostream>
#include <fstream>				//input ,output library.
#include <iomanip>
#include <cstring>				//library to convert string to character.
using namespace std;

  //*****Declare the global variables.*****
	//..........As given......

const int size = 3 ;
const int  MAX_BOOK_ID  =  13 ;
const int  DATE_SIZE    =  11 ;
const int  MAX_COPY_NUMBER   =  17 ;
const int  MAX_BOOKS    =  200 ;
const int  MAX_CATEGORIES    =   30 ;
const int  MAX_BOOK_NAME =  60 ;
const int  MAX_CATEGORY_NAME =   20 ;
const int  MAX_CATEGORY_NUMBER  =  4  ;
//char bookCategory [MAX_BOOK_ID]
char CategoryNo [MAX_CATEGORIES][MAX_CATEGORY_NUMBER];
char CategoryName [MAX_CATEGORIES][MAX_CATEGORY_NAME];
char CategoryId [MAX_CATEGORY_NUMBER];
char prevCategoryId[MAX_CATEGORY_NUMBER];
char prevCategoryName[MAX_CATEGORY_NAME];
char newCategoryId[MAX_CATEGORY_NUMBER];
char newCategoryName[MAX_CATEGORY_NAME];

int ArraySize=0;


void printMenu();
void TakeMenuInput(int& mainOption, char& subOption);


   //******** Now enter the book id and ********
   //*****check wether it is valid or not.*****

//first make a fuction....
void printMenu()
{
	cout<<"\nChoose the following option\n";
	cout<< "1 Category Management(A,E,L,D)\n";
	cout<<" 2 Books Management(A,E,L,D)\n";
	cout<<" 3 Book Copies Management(A,E,L,D)\n";
	cout<<" 0  Exit Program(0E)\n";
}

//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

void TakeMenuInput(int& mainOption, char& subOption)
{
	cin>>mainOption;
	cin>>subOption;
	/*
	char x,y ;
	cout << "\nEnter the input .\n";
	cin.get(x);
	cin.get(y);
	
	int a=x;
	mainOption = a-48;
	subOption = y ;
	*/
}

//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

bool isValidCategoryNumber (char bookCategory [])
{
	int h;

	for (int i=0; i<MAX_CATEGORY_NUMBER ; i++)
	{
		if (bookCategory [i]>='0' && bookCategory [i]<='9')
		{
			h=1;
		}

		if (h==1)
		{
			return true;
		}
		else
			return false;
	}
}


bool isValidCategoryName (char bookCategory [])
{
	bool x,y;

	for(int k=0; k<MAX_CATEGORY_NAME ; k++)
	{
		if (bookCategory[k] >='A' && bookCategory[k] <='Z' && bookCategory[k] >='a' && bookCategory[k] <='z' );

			x = 1 ;
		//else
		  //  x = 0 ;
	}

	if (x==1)
	{
		return true ;
	}
	else
		return false ;
}	

//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

	bool AddCategory(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize, char newCategoryId[], char newCategoryName[]) 
	{
		bool flag = false;
		for (int i=0 ;i<MAX_CATEGORIES ; i++)
		{
			for (int j=0 ;j<MAX_CATEGORY_NUMBER ; j++)
			{
				if(CategoryNo[i][j] =='-')
				{
					CategoryNo[i][j] = newCategoryId[j] ;
					flag = true ;
				} 
			}
			if (flag==true)
			{
				break;
			}
			
			for (int i=0 ;i<MAX_CATEGORIES ; i++)
			{
			for (int j=0 ;j<MAX_CATEGORY_NAME ; j++)
			{
				if(CategoryName[i][j] =='-')
				{
					CategoryName[i][j] = newCategoryName[j] ;
					flag = true ;
				} 
			}
			if (flag==true)
			{
				break;
			}
			
			
		}
		return true;
		
	}
}

//***********************************************************************************************************************************************************************************

	
bool UpdateCategory(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize, char prevCategoryId[], char newCategoryId[], char newCategoryName[]) 
{
		bool flag2 = false ;
		 
		for (int i=0 ; i<MAX_CATEGORIES ; i++)
		{
			//for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
			//{
				if (CategoryNo [i][0] == prevCategoryId[0] && CategoryNo [i][1] == prevCategoryId[1] && CategoryNo [i][2] == prevCategoryId[2])
				{
					for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
					{
						CategoryNo [i][j] = newCategoryId[j] ;
						return true ;
					}
					
				}
				if (flag2==true)
				{
					break;
				}
			//}
		}
		
		 
		for (int i=0 ; i<MAX_CATEGORIES ; i++)
		{
			//for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
			//{
				if (CategoryName [i][0] == prevCategoryName [0] && CategoryName [i][1] == prevCategoryName[1] && CategoryName [i][2] == prevCategoryName[2])
				{
					for (int j=0 ; j<MAX_CATEGORY_NAME ;j++)
					{
						CategoryName [i][j] = newCategoryName[j] ;
						return true ;
					}
					
				}
				if (flag2==true)
				{
					break;
				}
			//}
		}
		return true;
		
}
	
//*************************************************************************************************************************************************************

bool DeleteCategory(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize, char CategoryId[]) 
{
	int location ;
	
	for (int i=0; i<MAX_CATEGORIES ; i++)
	{
		int loop = 0 ;
		 
		for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
		{
			CategoryNo [i][j] = CategoryId[j] ;
			location = i ;
			loop++;
		}
		if (loop==MAX_CATEGORY_NUMBER)
		{
			break;
		}
	}
	for (int i=0; i<MAX_CATEGORY_NUMBER ;i++)
	{
		CategoryNo [location][i] = '-';
	}
	
	return true;
}

//****************************************************************************************************************************************************************************************
	
void PrintCategories(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize) 
{
	cout << endl << "Categories ID\t\t Categories Name\n";
	
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NUMBER ; j++)
		{
			
			cout << CategoryNo[i][j] <<"\n" ; 
		}
		cout << "\n";
		
		for (int k=0 ; k<MAX_CATEGORY_NAME ; k++)
		{
			cout << CategoryName[i][k] <<"\n" ;
		}
		cout << "\n";
	}
	
}

//*******************************************************************************************************************************************************************************************

bool SaveCategories(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize) 
{
	ofstream File1 ;
	File1.open ("PHASE 1 Categories.txt");			//Open file .
	
	File1 << "The details of Category ID Data is as follows :\n";
	
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
		{
		
			File1<<CategoryNo[i][j];
		}
		File1 << "\n";
	}
	
	File1 << "The details of Category Name Data is as follows :\n";
	
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NAME ;j++)
		{
			File1 << CategoryName[i][j] ;
		}
		File1 << "\n";
	}
	
	File1.close ();				//Close file .
	
}

//***************************************************************************************************************************************************************************************

bool LoadCategories(char CategoryNo[][MAX_CATEGORY_NUMBER],char CategoryName[][MAX_CATEGORY_NAME], int ArraySize)
{
	
	ifstream File1 ;
	
	File1.open ("PHASE 1 Categories.txt");			//Open file .

	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
		{
		
			File1 >> CategoryNo[i][j];
		}
	}
	
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NAME ;j++)
		{
			File1 >> CategoryName[i][j] ;
		}
	}
	
	File1.close ();				//Close file .
	
	
}


//,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,

int main()
{
	char CategoryNo [MAX_CATEGORIES][MAX_CATEGORY_NUMBER];
	
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NUMBER ;j++)
		{
			CategoryNo[i][j]='-' ;
		}
	}
	for (int i=0 ; i<MAX_CATEGORIES ; i++)
	{
		for (int j=0 ; j<MAX_CATEGORY_NAME ;j++)
		{
			CategoryName[i][j]='-' ;
		}
	}
	

	int mainOption;
	char subOption;
	
	cout <<"\n";
	cout <<"\n";
	
	cout<<"\t\t\t\t**************WELCOM TO THE LIBRARY MANAGEMENT SYSTEM***************\t\t\n";
	
	
	printMenu();
		
	cout <<"Choose the following options: ";
	TakeMenuInput(mainOption,subOption);
	
	while (mainOption!=0)
	{
		switch (mainOption)
		{
			case 1:
				if (subOption=='A')
				{
				
					cout<<"Enter the details of category (ID Name) :";
					
					cin>>newCategoryId;
					cin>>newCategoryName;
					
					bool  result;
					bool  result1;
					int ln ;
					
					ln = strlen (newCategoryId );
					//cout << "length od newCategoryId is :"<<ln<<"\n";
					
					//if (ln <= 3)
					//{
					result = isValidCategoryNumber (newCategoryId) ;
					//}
					//else 
					//cout << "OUT OF RANGE .\n";
					/*if (result==1)
					{
						cout <<"valid.\n";
					}*/
					result1 = isValidCategoryName (newCategoryName) ;
					/*if(result1==1)
					{
						cout<<"isvalid.\n";
					}*/

					if (result==1&&result1==1)
					{
						bool test=AddCategory(CategoryNo,CategoryName,ArraySize,newCategoryId,newCategoryName) ;
						
						if(test==1)
						{
							cout<<"Category has been added successfully.";
							PrintCategories(CategoryNo,CategoryName,ArraySize);
						}
						else
						{
							cout<<"Category has not been added successfully.\n";
						}
					}
					
				}
				
				else
				
			//case 1 :
				if (subOption=='E')
				{
				cout << "Enter the category ( ID Name ) to Edit :\n";
				
				cin >> prevCategoryId;
				cin >> prevCategoryName;
				
				cout <<"Enter the new details of category ( ID  Name ) :";
				
				cin>>newCategoryId;
				cin>>newCategoryName;
				
				bool  result2;
				bool  result3;
				bool test1;
				
				int len =	strlen (newCategoryId) ;
				cout << "The length of newcategoryID is "<<len <<"\n";
				
				if (len <= 3 )
				{
				
				result2 = isValidCategoryNumber (newCategoryId) ;
				if (result2==1)
				{
					cout <<"valid.\n";
				}
				}
				else 
				cout << "OUT OR RANGE .\n";
				
				result3 = isValidCategoryName (newCategoryName) ;
				if(result3==1)
				{
					cout<<"isvalid.\n";
				}
					
				test1 = UpdateCategory(CategoryNo,CategoryName,ArraySize,prevCategoryId,newCategoryId,newCategoryName);
				if (test1==1)
				{
					cout << "Category has been edited successfully .\n";
					PrintCategories(CategoryNo,CategoryName,ArraySize);
				}
				else
					cout << "Category has not been edited successfully .\n";
				
				}
				
				else	
				
				//case 1:
				if (subOption == 'D')
				{
					cout << "Enter the category Id to delete: ";
					
					cin >> CategoryId ;
					
					bool test2;
					
					test2 = DeleteCategory(CategoryNo,CategoryName,ArraySize,CategoryId);
					{
						if (test2==1)
						{
							cout << "Category has been deleted successfully.\n" ;
							PrintCategories(CategoryNo,CategoryName,ArraySize);
						}
						else 
							
							cout << "Category has not been deleted successfully.\n" ;
							
					}
					
				}
				
				else 
				
				//case 1 :
				
				if (subOption=='L')
				{
					LoadCategories(CategoryNo,CategoryName,ArraySize);
					PrintCategories(CategoryNo,CategoryName,ArraySize);
				}
		}
		printMenu();
		
		cout <<"Choose the following options: ";
		TakeMenuInput(mainOption,subOption);
	}
	
	if (mainOption==0)
	{
		//save;
	}
	
	
	return 0 ;
		
}

